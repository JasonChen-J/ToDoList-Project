//
//  EntryViewController.swift
//  Sinc
//
//  Created by jeisen on 6/14/20.
//  Copyright © 2020 jeisen. All rights reserved.
//

import UIKit

//Inheritate from UIViewController class, and UITextFieldDelegate class.
class EntryViewController: UIViewController,UITextFieldDelegate {

    //create a field varible
    @IBOutlet var field:UITextField!
    
    var update: (()->Void)?
    
    //??
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //better handling event??
        field.delegate = self
        
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveTask))
        // Do any additional setup after loading the view.
    }
     
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
    
        saveTask()
        return true
    }
    
    @objc func saveTask()
    {

        guard let text = field.text, !text.isEmpty else
        {
            return
        }

        category = text
        UserDefaults().set(0, forKey: category)
        guard let count = UserDefaults.standard.integer(forKey: key2) as? Int else
        {
            return
        }

        let newCount = count + 1
        UserDefaults().set(newCount, forKey: key2)
        UserDefaults().set(text, forKey: "task_\(newCount)")
        UserDefaults().set("yes", forKey: "key1")
        
        
        update?()
        
        navigationController?.popViewController(animated: true)
    }

}
