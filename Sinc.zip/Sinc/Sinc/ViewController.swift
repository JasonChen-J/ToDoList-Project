//
//  ViewController.swift
//  Sinc
//
//  Created by jeisen on 6/14/20.
//  Copyright © 2020 jeisen. All rights reserved.
//

var key2 = "key2"
var key3 = "key3"
var category = ""

var tasks = [String]()

import UIKit

 class ViewController: UIViewController{
    
    //create an array to handle all task
    
    var myIndex = 0
    var defaultName = "initial"
    var defaultCount = "first"
    
    //connect variable to actuall Table View, why use ! tho??
    @IBOutlet var tableView:UITableView!

    override func viewDidLoad()
    {
        registerNotification()
        super.viewDidLoad()
        
        if !UserDefaults().bool(forKey: "key1")
        {
            UserDefaults().set(true,forKey:"key1")
            UserDefaults().set(0,forKey:key2)

        }
        tableView.delegate = self
        tableView.dataSource = self
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Clean", style: .done, target: self, action: #selector(deleteAll))
        
        
    //setup
        
        updateTasks()
    }
    
    func registerNotification()
    {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.badge,.sound], completionHandler: {success,error in
            if error != nil
            {
                print("error occur")
            }
        })
    }
    //created notification request and date
    //created date picker and send that date to request and push notification
    
    func updateTasks()
    {
        tasks.removeAll()
        guard let count = UserDefaults.standard.integer(forKey: key2) as? Int else
        {
            return
        }
        for x in 0..<count
        {
            if let task = UserDefaults.standard.string(forKey: "task_\(x+1)") as? String
            {
                tasks.append(task)
            }
        }
        print(tasks)
        tableView.reloadData()
        
    }
    
    @IBAction func didTapAdd()
    {
        let vc = storyboard?.instantiateViewController(identifier: "entry") as! EntryViewController
        navigationController?.pushViewController(vc, animated: true)
        vc.title = "New Plans"
        vc.update =
        {
            DispatchQueue.main.async {
                self.updateTasks()
            }
        }
        
    }
    
    @objc func deleteAll()
    {
        UserDefaults().set(0, forKey: key2)
        for x in tasks
        {
        UserDefaults().set(0, forKey: x)
        }
        tasks.removeAll()
        tasks2.removeAll()
        tableView.reloadData()
    }
    
    func deleteOne(index:Int)
    {
        
        if index==0
        {
            UserDefaults().set(tasks.count, forKey: key2)
            UserDefaults().set(0, forKey: tasks[index])
            tasks.remove(at: index)
            //UserDefaults().set("", forKey: key3)
            tableView.reloadData()
        }
        else
        {
            index-1
            UserDefaults().set(tasks.count, forKey: key2)
            UserDefaults().set(0, forKey: tasks[index])
            //UserDefaults().set("", forKey: key3)
            tableView.reloadData()
        }
    }
    
    

}



extension ViewController:UITableViewDelegate
{
    //handling tap event
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        let tvc = storyboard?.instantiateViewController(identifier: "task") as! TaskViewController
        navigationController?.pushViewController(tvc, animated: true)
        var title = tasks[indexPath.row]
        tvc.title = title
        
        tableView.deselectRow(at: indexPath, animated: true)
        category = tasks[indexPath.row]
        
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        //??????
        let delete = UIContextualAction(style: .destructive, title: "Delete")
        {
            (ContextualAction, view, actionPerformed: (Bool)->()) in
            self.deleteOne(index: indexPath.row)
        }
        return UISwipeActionsConfiguration(actions: [delete])
    }
}

extension ViewController:UITableViewDataSource
{
    //return number of task (number of rows)
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    //deque cell, and return the cell at a specific cell position.
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        //return the task from a cell
        cell.textLabel?.text = tasks[indexPath.row]

        
        return cell
    }
}


