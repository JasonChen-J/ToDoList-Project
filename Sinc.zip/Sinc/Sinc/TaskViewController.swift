//
//  TaskViewController.swift
//  Sinc
//
//  Created by jeisen on 6/14/20.
//  Copyright © 2020 jeisen. All rights reserved.
//
var tasks2 = [String]()
import UIKit

class TaskViewController: UIViewController {

        var myIndex2 = 0
        //connect variable to actuall Table View, why use ! tho??
        @IBOutlet var tableView2:UITableView!

        override func viewDidLoad()
        {

            
            super.viewDidLoad()
            tableView2.delegate = self
            tableView2.dataSource = self
            
        //setup
            if !UserDefaults().bool(forKey: "key11")
            {
                UserDefaults().set(true,forKey:"key11")
                UserDefaults().set(0,forKey:category)
            }
            navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Add", style: .bordered, target: self, action: #selector(push))
            
            updateTasks2()

        }
    
        func updateTasks2()
        {
            tasks2.removeAll()
            
            guard let count2 = UserDefaults.standard.integer(forKey: category) as? Int else
            {
                return
            }
            
            for x in 0..<count2
            {
                if let task2 = UserDefaults.standard.string(forKey: category+"\(x+1)") as? String
                {
                    tasks2.append(task2)
                }
            }
            
            tableView2.reloadData()
            
        }
        
        @objc func push()
        {
            let tvc = storyboard?.instantiateViewController(identifier: "detail") as! DetailViewController
            navigationController?.pushViewController(tvc, animated: true)
            tvc.title = "Elements"
            tvc.update2 =
            {
                DispatchQueue.main.async {
                    self.updateTasks2()
                }
            }
        }
    
    
    func deleteOne(index:Int)
        {
            tasks2.remove(at: index)
            UserDefaults().set(tasks2.count, forKey: key2)
            tableView2.reloadData()
        }
 
    
        
        
    }

    extension TaskViewController:UITableViewDelegate
    {
        //handling tap event
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
        {
            tableView.deselectRow(at: indexPath, animated: true)
        }
        
        
        func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
        {
            //??????
            let delete = UIContextualAction(style: .destructive, title: "Delete")
            {
                (ContextualAction, view, actionPerformed: (Bool)->()) in
                self.deleteOne(index: indexPath.row)
            }
            return UISwipeActionsConfiguration(actions: [delete])
        }
 
 
    }
    extension TaskViewController:UITableViewDataSource
    {
        //return number of task (number of rows)
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return tasks2.count
        }
        
        //deque cell, and return the cell at a specific cell position.
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell2 = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath)
            
            //return the task from a cell
            cell2.textLabel?.text = tasks2[indexPath.row]
            return cell2
        }
    }




