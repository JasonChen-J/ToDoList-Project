//
//  DetailViewController.swift
//  Sinc
//
//  Created by jeisen on 6/15/20.
//  Copyright © 2020 jeisen. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController, UITextFieldDelegate {

        @IBOutlet var field2:UITextField!
    
        @IBOutlet var descriptionField:UITextField!
    
        @IBOutlet var datePicker:UIDatePicker!
    
        @IBOutlet var reward:UITextField!
    
        
        var update2: (()->Void)?
    
        
        
        //??
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            //better handling event??
            field2.delegate = self
            
            
            navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveTask2))
            // Do any additional setup after loading the view.
        }
         
        func textFieldShouldReturn(_ textField: UITextField) -> Bool
        {
        
            saveTask2()
            return true
        }
        
        @objc func saveTask2()
        {
            
            guard let text2 = field2.text, !text2.isEmpty else
            {
                return
            }
            guard let count2 = UserDefaults.standard.integer(forKey: category) as? Int else
            {
                return
            }
            
            let targetDate = datePicker.date
            
            let newCount2 = count2 + 1
            UserDefaults().set(newCount2, forKey: category)
            UserDefaults().set(text2, forKey: category+"\(newCount2)")
            UserDefaults().set("yes", forKey: "key11")
            
            
            let content = UNMutableNotificationContent()
            content.title = text2
            content.sound = .default
            content.body = "5 Seconds to go!"
            
            let date = datePicker.date
            let trigger = UNCalendarNotificationTrigger(dateMatching: Calendar.current.dateComponents([.year,.month,.day,.hour,.minute,.second],from: date), repeats: false)
            
            let request = UNNotificationRequest(identifier: "Id_\(date)", content: content, trigger: trigger)
            UNUserNotificationCenter.current().add(request, withCompletionHandler: {error in
                if error != nil
                {
                    print("something wrong")
                }
            })
            
            update2?()
            
            navigationController?.popViewController(animated: true)
        }

    }
